import SwiftUI

struct ContentView: View {
  @State private var redValue: Double = 0.0
  @State private var greenValue: Double = 255.0
  @State private var blueValue: Double = 255.0
  @State private var rectangleColor: Color = Color(red: 0/255, green: 255/255, blue: 255/255 )
  
  var body: some View {
    VStack {
      Text("🕊️Color Picker").tracking(9.0)
        .font(.largeTitle) // Bigger title font
        .foregroundColor(.orange) // Dark color
      RoundedRectangle(cornerRadius: 10) // Rounded rectangle shape
        .fill(rectangleColor)
        .frame(width: 300, height: 300)
        .padding()
      
      VStack(spacing: 20) {
        // Red Slider
        SliderTitleView(title: "Red", value: $redValue)
          .accentColor(.red)
        // Green Slider
        SliderTitleView(title: "Green", value: $greenValue)
          .accentColor(.green)
        // Blue Slider
        SliderTitleView(title: "Blue", value: $blueValue)
          .accentColor(.blue)
      }
      .padding()
      // Set Color Button
      Button(action: {
        self.rectangleColor = Color(
          red: redValue / 255,
          green: greenValue / 255,
          blue: blueValue / 255
        )
      }) {
        Text("Set Color")
          .foregroundColor(.white)
          .padding()
          .background(Color.blue)
          .cornerRadius(10)
      }
      .padding()
    }
  }
}

struct SliderTitleView: View {
  let title: String
  @Binding var value: Double
  
  var body: some View {
    VStack(alignment: .center) {
      Text(title)
        .foregroundColor(title == "Red" ? .red : title == "Green" ? .green : title == "Blue" ? .blue : .black)
        .bold() // Making the font bold
        .frame(maxWidth: .infinity, alignment: .center)
      
      HStack {
        Slider(value: $value, in: 0...255, step: 1)
        Text("\(Int(value))")
          .foregroundColor(title == "Red" ? .red : title == "Green" ? .green : title == "Blue" ? .blue : .black)
          .bold() // Making the font bold
          .frame(width: 50, alignment: .leading) // Fix the width and alignment
      }
    }
    .padding(.horizontal) // Add padding for better alignment
  }
}

#Preview{
  ContentView()
}
