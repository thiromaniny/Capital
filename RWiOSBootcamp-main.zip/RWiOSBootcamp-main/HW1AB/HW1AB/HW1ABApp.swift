//
//  HW1ABApp.swift
//  HW1AB
//
//  Created by sam on 6/6/24.
//

import SwiftUI

@main
struct HW1ABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
