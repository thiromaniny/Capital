//1: Create a protocol called Shape with a calculateArea() -> Double method. Create two structs called Circle and Rectangle that conform to the protocol Shape. Both Circle and Rectangle should have appropriate stored properties for calculating the area.
extension Numeric {
  var squared: Self { self * self }
  var qubed: Self { self * self * self }
}
protocol Shape {
  func calculateArea() -> Double
}

//  2: Create struct Circle conforming to Shape
struct Circle: Shape {
  let radius: Double
  
  // Implement calculateArea method for Circle
  func calculateArea() -> Double {
    return Double.pi * radius.squared
  }
}

// Step 3: Create struct Rectangle conforming to Shape
struct Rectangle: Shape {
  let width: Double
  let height: Double
  
  // Implement calculateArea method for Rectangle
  func calculateArea() -> Double {
    return width * height
  }
}

// 3: Create instances of Circle : with radius 5.0 and Rectangle: with width 10.0 & height 8.0
// MARK: -  print out the area for each
let circle = Circle(radius: 5.0)
let rectangle = Rectangle(width: 10.0, height: 8.0)

print("Area of the circle: \(circle.calculateArea())")
print("Area of the rectangle: \(rectangle.calculateArea())")

// 4)
// MARK: -  extend the protocol Shape to add a new method called calculateVolume() -> Double
// Default implementation for 2D shapes (circles and rectangles)
extension Shape {
  func calculateVolume() -> Double {
    return 0
  }
}
// 5:creat e a struct called Sphere that conforms to Shape.
//Sphere  stored properties for calculating area and volume
// Create struct Sphere conforming to Shape
struct Sphere: Shape {
  let radius: Double
  //Area = 4 * π * r^2
  func calculateArea() -> Double {
    return 4 * Double.pi * radius.squared
  }
  //  Volume = (4/3) * π * r^3
  func calculateVolume() -> Double {
    return (4/3) * Double.pi * radius.qubed
  }
}

// 6: Create instance of Sphere and print area and volume
let sphere = Sphere(radius: 5.0)

print("Area of the sphere: \(sphere.calculateArea())")
print("Volume of the sphere: \(sphere.calculateVolume())")
