// Part 1 - Programming Assignment
//***************
// MARK: - A)
//********
// Create an array of Int called nums with values 0 through 20
//let nums = Array(0...20)
let nums: [Int] = Array(0...20)
// Iterate over the array and print the even numbers
for number in nums {
  if number % 2 == 0 {
    print(number)
  }
}
//***************
// MARK: -  B)
//********
let sentence = "The qUIck bRown fOx jumpEd over the lAzy doG"
let vowels: Set<Character> = ["a", "e", "i", "o", "u"]
var vowelCount = 0

for char in sentence {
  // Convert the character to lowercase for case-insensitive comparison
  let lowercaseChar = char.lowercased().first!
  // Check if the lowercase character is a vowel
  if vowels.contains(lowercaseChar) {
    vowelCount += 1
  }
}

print("Total vowels in the sentence: \(vowelCount)")
//***************
// MARK: -  C)
//********
import Foundation

let array1 = [0, 1, 2, 3, 4]
let array2 = [0, 1, 2, 3, 4]

//outer loop iterates over each element in array1
for i in array1 {
  //each element in array2 for every iteration of the outer loop
  for j in array2 {
    //string interpolation mini multiplication table
    print("\(i) * \(j) = \(i * j)")
  }
}
//***************
// MARK: -  D)
// TODO: average of array
//********

func average(of array: [Int]?)  {
  if let array = array {
    
    var sum = 0
    for number in array {
      sum += number
    }
    let avg = sum / array.count
    print("The average of the values in the array is \(avg).")
    
  } else {
    print("The array is nil. Calculating the average is impossible.")
  }
}

// Example usage:
let numsD: [Int]? = [10, 20, 30, 40, 50]
average(of: numsD)  // The average of the values in the array is 30.0.

let optionalArray: [Int]? = nil
average(of: optionalArray)  // The array is nil. Calculating the average is impossible.

//***************
// MARK: -  E)
//********
struct Person {
  var firstName: String
  var lastName: String
  var age: Int
  
  func details() {
    print("Name: \(firstName) \(lastName), Age: \(age)")
  }
}

// Creating an instance of Person
let personE = Person(firstName: "JohnE", lastName: "Ford", age: 30)

// Calling the details method
personE.details()

//***************
// MARK: - F)
//value types (Person struct) and reference types (Student class)  differently  copied and modified.
//********

class Student {
  var person: Person
  var grades: [Int]
  
  init(person: Person, grades: [Int]) {
    self.person = person
    self.grades = grades
  }
  
  func calculateAverageGrade() -> Double {
    var sum = 0
    for grade in grades {
      sum += grade
    }
    return Double(sum) / Double(grades.count)
  }
  
  func details() {
    let averageGrade = calculateAverageGrade()
    print("Name: \(person.firstName) \(person.lastName), Age: \(person.age), GPA: \(averageGrade)")
  }
}

// new instance (person) of the Person struct, firstName, lastName, and age.
//a value type, a unique copy.
let person = Person(firstName: "TimF", lastName: "Wayne", age: 25)

//copy of the person instance,  grades property,a reference to the array (new)
let student = Student(person: person, grades: [94, 99, 81, 100, 79])

// Call the details method to print the student's details
student.details()
//*****************
// MARK: - Part 2
//*****************
//value type
struct Square {
  var side: Int
  func area() -> Int {
    return side * side
  }
}
//reference type
class Rectangle {
  var length: Int
  var width: Int
  init(length: Int, width: Int) {
    self.length = length
    self.width = width
  }
  func area() -> Int {
    return length * width
  }
}

var square1 = Square(side: 4)
var square2 = square1
//Changing square2.side to 5 does not affect square1.
square2.side = 5
print("Area: square1 - \(square1.area()) square2 - \(square2.area())")

var rectangle1 = Rectangle(length: 4, width: 4)
var rectangle2 = rectangle1
//references to the same instance, changing length through rectangle2 affects rectangle1 as well
rectangle2.length = 5
print("Area: rectangle1 - \(rectangle1.area()) rectangle2 - \(rectangle2.area())")
