//***************
// MARK: -  A)
//In the assignment for Week 2, part D asked you to write a function that would compute the average of an array of Int. Using that function and the array created in part A, create two overloaded functions of the function average.
////********
///
//let nums: [Int] = Array(0...20)
//for num in nums where num.isMultiple(of: 2) {
//  print(num)
//}
let numsDB: [Double] = Array(stride(from: 0.0, to: 21.0, by: 1.0))
for num in numsDB where num.truncatingRemainder(dividingBy: 2.0) == 0.0 {
  print(num)
}


func average(of array: [Int]?) {
  if let array = array, !array.isEmpty {
    
    var sum = 0
    for number in array {
      sum += number
    }
    let avg = sum / array.count
    print("The average of the values in the array is \(avg).")
    
  } else if array == nil {
    print("The array is nil. Calculating the average is impossible.")
  } else {
    print("The array is empty. Calculating the average is impossible.")
  }
}
// TODO: handle an array of Double:

func average(of array: [Double]?) {
  if let array = array, !array.isEmpty {
    var sum = 0.0
    for number in array {
      sum += number
    }
    let avg = sum / Double(array.count)
    print("The average of the values in the array is \(avg).")
  } else if array == nil {
    print("The array is nil. Calculating the average is impossible.")
  } else {
    print("The array is empty. Calculating the average is impossible.")
  }
}
// TODO: handle a variable number of Int arguments:
func average(of numbers: Int...) {
  if numbers.isEmpty {
    print("No numbers provided. Calculating the average is impossible.")
  } else {
    var sum = 0
    for number in numbers {
      sum += number
    }
    let avg = Double(sum) / Double(numbers.count)
    print("The average of the values is \(avg).")
  }
}


let numsD: [Int]? = [10, 20, 30, 40, 50]
average(of: numsD)  // The average of the values in the array is 30.0.

let optionalArray: [Int]? = nil
average(of: optionalArray)  // The array is nil. Calculating the average is impossible.

average(of: 1, 2, 3, 4, 5)       // Test with multiple numbers
average(of: 10, 20, 30)          // Test with another set of numbers
average(of: 7)                   // Test with a single number
average(of: -5, 0, 5, 10, 15)    // Test with a mix of negative and positive numbers
average(of: 4, 8, 15, 16, 23, 42)// larger set of numbers 18=(108/6)

// MARK: -  B)
// Define the enum with five animals
enum Animal {
  case cow
  case dog
  case cat
  case sheep
  case duck
}

// Define the function to output the sound made by the animal
func theSoundMadeBy(_ animal: Animal) {
  switch animal {
  case .cow:
    print("A cow goes moooo.")
  case .dog:
    print("A dog goes woof.")
  case .cat:
    print("A cat goes meow.")
  case .sheep:
    print("A sheep goes baa.")
  case .duck:
    print("A duck goes quack.")
  }
}

// Call the function twice with different animals
theSoundMadeBy(.cow)
theSoundMadeBy(.cat)

// MARK: -  C)

// Step 1: Creating the arrays Range
let nums: [Int] = Array(0...100)
let numsWithNil: [Int?] = [79, nil, 80, nil, 90, nil, 100, 72]
let numsBy2: [Int] = Array(stride(from: 2, through: 100, by: 2))
let numsBy4: [Int] = Array(stride(from: 2, through: 100, by: 4))

// Step 2: Function to get even numbers from an array
func evenNumbersArray(from array: [Int]) -> [Int] {
  return array.filter { $0 % 2 == 0 }
}

// Call the function passing the nums array and print the output.
let evenNums = evenNumbersArray(from: nums)
print("Even numbers from nums array: \(evenNums)")

// Step 3: Function to sum non-nil values in array, optional Int?
func sumOfArray(_ array: [Int?]) -> Int {
  return array.compactMap { $0 }.reduce(0, +)
}
// Call the function passing the numsWithNil array, and print results.
let sumNumsWithNil = sumOfArray(numsWithNil)
print("Sum of non-nil values in numsWithNil array: \(sumNumsWithNil)")

// Step 4: Function to find common elements in two arrays
func commonElementsSet(array1: [Int], array2: [Int]) -> Set<Int> {
  let set1 = Set(array1)
  let set2 = Set(array2)
  return set1.intersection(set2)
}
let array1 = [1, 2, 3, 4]
let array2 = [3, 4, 5, 6]
let commonSet = commonElementsSet(array1: array1, array2: array2)
print(commonSet) // Output: [3, 4]


// Step 5: Calling the functions and printing the results

let commonElements = commonElementsSet(array1: numsBy2, array2: numsBy4)
let sortedCE = commonElements.sorted()
print("Common elements in numsBy2 and numsBy4 Sorted: \(sortedCE)")
//
// MARK: -  D)
// Define the Square struct
// the extension on Numeric to use the squared property
extension Numeric {
  var squared: Self { self * self }
}
struct Square {
  // Stored property
  var sideLength: Double
  
  // Computed property
  var area: Double {
//    return sideLength * sideLength
    return sideLength.squared
  }
}

// Create an instance of Square
let mySquare = Square(sideLength: 5.0)

// Print out the area
print("The area of the square is \(mySquare.area).")

